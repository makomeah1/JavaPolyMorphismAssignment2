package javaPolymorphism2;




public class Q1 {

	public static void main(String[] args) {
		staff GCB = new staff();
		
       GCB.stafflist = new staffMember[8];    

       Commission poly = new Commission("Gina"," Accra,Ghana", "23354112200","A0012GH", 6.25,0.20);
       poly.addSales(400);
       poly.sethoursWorked(35);
       System.out.println(poly.Pay());
      
       Commission Kai = new Commission("Sam"," Takoradi,Ghana", "23354100200","B0014GH", 9.75,0.15);
       Kai.addSales(950);
       Kai.sethoursWorked(40);
       System.out.println(Kai.Pay());
}
	
}	
	
	class staff{
		 staffMember[] stafflist;	
		 
		 void payday() {
			 System.out.println("Payday");
		 }
	}


abstract class staffMember extends staff{
	protected String name;
	protected String Address;
	protected String  phoneNumber;
	
	
	staffMember(String name, String Address,String phoneNumber){
		this.name=name;
		this.Address=Address;
		this.phoneNumber=phoneNumber;
		
		
	}
	
	String setName(String name) {
		return this.name=name;
	}
	String getName() {
		return name;
	}

	
	String setAddress(String Address) {
		return this.Address=Address;
	}
	

	String getAddress() {
		return Address;
	}
	
	
	String setphoneNumber(String Num) {
		return phoneNumber=Num;
	}
	
	String getphoneNumber() {
		return phoneNumber;
	}
	
	public String toString() {
		return name+" " + Address+" "+phoneNumber;
	}
	public abstract double Pay();
	
}



abstract class Employee extends staffMember{
	protected String socialSecuritNumber;
	protected double hourly_pay_rate;
	
	
	Employee(String name, String Address,String phoneNumber,String socialSecuritNumber,double hourly_pay_rate){
		super(name,Address,phoneNumber);
		this.socialSecuritNumber=socialSecuritNumber;
		this.hourly_pay_rate= hourly_pay_rate;		

	}

 String setSocialSecuritNumber(String SSN) {
	return socialSecuritNumber=SSN; 
 }
 String getSocialSecuritNumber() {
		return socialSecuritNumber; 
	 }
 
  double SetHourPayrate(double rate) {
	  return hourly_pay_rate=rate ;
  }
 
  double getHourPayrate() {
	  return hourly_pay_rate;
  }
 public abstract double Pay();

	public String toString() {
		return super.toString()+" "+socialSecuritNumber+ " "+ hourly_pay_rate;
	}
 
 
}

class Executive extends Employee{
	private double bonus;
	protected double salary;
	Executive(String name, String Address,String PhoneNumber,String socialSecuritNumber,double hourly_pay_rate,double bonus, double salary){
		super(name,Address,PhoneNumber,socialSecuritNumber,hourly_pay_rate);
		this.bonus=bonus;
	
	}
	double awardbonus(double bonus) {
		return this.bonus=bonus;
	}
	
	double getbonus() {
		return bonus;
	}
	double setBasesalary(double salary) {
		return this.salary = salary;
	}
	double getBasesalary() {
		return salary;
	}
	
	public String toString() {
		return super.toString()+" "+ bonus +" "+salary;
	}
 
	public double Pay() {
		return  getBasesalary()+getbonus();
		
		
	}
	
}


class Hourly extends Employee{
	private int hoursWorked;
	
	Hourly(String name, String Address,String PhoneNumber,String socialSecuritNumber,double hourly_pay_rate){
		super(name,Address,PhoneNumber,socialSecuritNumber,hourly_pay_rate);	
	}
	
	
	
  double sethourly_pay_rate(double rate)	{
	 return hourly_pay_rate= (rate>0 &&rate<1)? rate:0.0;
  }
	
  double gethourly_pay_rate()	{
		 return hourly_pay_rate;
	  }
  
  int sethoursWorked(int hoursWorked)	{
		return this. hoursWorked = hoursWorked;
	  }
  
  
  int gethoursWorked()	{
		return hoursWorked;
	  }
  
  
  public  double Pay() {
	  return hoursWorked*hourly_pay_rate;
	  
	  
  }

 	public String toString() {
 		return super.toString();
 	}
  
  
}


class Commission extends Hourly {
	
	
	double total_sales;
	double commission_rate;
	
	Commission(String name, String Address,String PhoneNumber,String socialSecuritNumber,double hourly_pay_rate,double commission_rate){
		super(name,Address,PhoneNumber,socialSecuritNumber,hourly_pay_rate);
		this.commission_rate=commission_rate;
	}
	 
	
	public void addSales (double totalSales) {
		 this.total_sales+=totalSales;
	 }
	 
	 
	 
	
	double setcommission_rate(double rate) {
		if (rate>0 && rate<1) {
		return commission_rate = rate;}
		return commission_rate=0;
		
	}
	 
	double getcommission_rate() {
		return commission_rate;
		
	}
	
	 public  double commisionPay() {
		  return total_sales*commission_rate;
		  
	}	  
	 
	 public  double Pay() {
		  return (gethoursWorked()*hourly_pay_rate)+commisionPay();
		  
		  
	  }

	 public String toString() {
	 		return super.toString()+ " "+commission_rate ;
	 	}



}



